module.exports = class RootController {
    constructor() {
        this.message = 'hello world';
    }
}
