var controller = require('./controller');

angular
    .module('chat-app')
    .component('music', {
        templateUrl: 'chat/content/music/template.html',
        controller
    });
