module.exports = class MovieController {
    constructor() {
    }
}
